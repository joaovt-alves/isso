import './style.css'


const LoginPage = ({children}) => {
  return (
    <>
    {children}
    </>
  )
}

export default LoginPage