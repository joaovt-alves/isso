import './style.css'


const SigninPage = ({children}) => {
  return (
    <>
    {children}
    </>
  )
}

export default SigninPage